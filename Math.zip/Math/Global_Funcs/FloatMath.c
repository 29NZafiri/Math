#include "FloatMath.h"
#include "../Constants.h"

float fltabs(float x) {
    if (x < 0) return -x;
    return x;
}
double dblabs(double x) {
    if (x < 0) return -x;
    return x;
}

_Bool DbInt(double a) {
    if (dblabs(a - (int)a) > err) return 0;
    return 1;
}

_Bool FlInt(float a) {
    if (fltabs(a - (int)a) > err) return 0;
    return 1;
}