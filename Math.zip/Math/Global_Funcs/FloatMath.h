#ifndef FLOATMATH_H
#define FLOATMATH_H

_Bool DbInt(double a);
_Bool FlInt(float a);

float fltabs(float x);
double dblabs(double x);

#endif //FLOATMATH_H
